//Deck of cards class
#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <stack>
#include "Card.h"
using namespace std;

const int SIZE(52);

class DeckOfCards
{
private:
    Card fullDeckofCards[SIZE];
    stack <Card> shuffledDeck;
public:
    DeckOfCards();
    void shuffleDeck();
    Card dealCard();
    void showDeck();
};