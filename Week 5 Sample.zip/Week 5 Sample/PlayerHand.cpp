//Player class implementation

#include "PlayerHand.h"

// Constructor
PlayerHand::PlayerHand(Card card, Card card2)
{
    hand.push_back(card);
    hand.push_back(card2);
    setScore(card);
    setScore(card2);
}


// Hit function
void PlayerHand::hit(Card card)
{
    if (checkBust())
    {
        cout << "Bust! You lose.\n";
    }
    else if (getScore() == 21)
    {
        cout << "Congratulations! You have a BlackJack!\n";
    }
    else
    {
        hand.push_back(card);
        handSize++;
        setScore(card);
    }

}

// Checks if player/dealer busts
bool PlayerHand::checkBust()
{
    bool bust = false;
    if (playerScore > 21)
    {
        bust = true;
    }
    return bust;
}

// Display cards
void PlayerHand::getHand()
{
    for (int count = 0; count < hand.size(); count++)
    {
        cout << hand[count] << endl;
    }
}

// Mutator
void PlayerHand::setScore(Card card)
{
    bool acesHigh = false;
    if (card.getFace() == card.ACE)
    {
        acesHigh = true;
    }

    if (card.getFace() == card.KING || card.getFace() == card.QUEEN || card.getFace() == card.JACK)
    {
        playerScore += 10;
    }
    else if (card.getFace() == card.ACE && acesHigh)
    {
        playerScore += 11;
        if (checkBust())
        {
            acesHigh = false;
            playerScore -= 10;
        }
    }
    else
    {
        playerScore += card.getFace();
    }

    if (checkBust())
    {
        cout << "Bust!" << endl;
    }
}

// Accessor
int PlayerHand::getScore()
{
    return playerScore;
}