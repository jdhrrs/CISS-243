//Player Class
#pragma once
#include <iostream>
#include <vector>
#include "DeckOfCards.h"
using namespace std;


class PlayerHand
{
private:
    int handSize = 2;
    int playerScore = 0;
    // Hold players cards
    vector<Card> hand;
public:
    // Constructor
    PlayerHand(Card, Card);

    // Mutator
    void setScore(Card);

    //Accessors
    void getHand();
    int getScore();

    //Member Functions
    void hit(Card);
    bool checkBust();
};

