//Week 5 sample

#include <iostream>
#include <string>
#include "DeckOfCards.h"
#include "PlayerHand.h"
using namespace std;

//add prototypes for the main method calls
int displayMenu();
void userPath(int);
void playBlackJack();
void gameChoices(PlayerHand&, DeckOfCards);
void determineWinner(PlayerHand, PlayerHand);


int main()
{
    int choice;
    choice = displayMenu();
    userPath(choice);

    cin.ignore();
    return 0;
}

// Menu
int displayMenu()
{
    int choice;
    cout << "Press 1 to play BlackJack \n";
    cout << "Press 2 to exit \n";
    cin >> choice;

    return choice;
}

// Execute Menu
void userPath(int choice)
{
    switch (choice)
    {
    case 1:
        playBlackJack();
        cout << "Press Enter to Exit: " << endl;
        cin.ignore();
        break;
    case 2:
        cout << "Press Enter to Exit: " << endl;
        cin.ignore();
        break;
    default:
        break;
    }
}

//Hit or hold choices for hte player
void gameChoices(PlayerHand& player, DeckOfCards deck)
{
    int choice;
    cout << "Your Hand" << endl;
    player.getHand();
    cout << "Press 1 to Hit" << endl;
    cout << "Press 2 to Stay" << endl;
    cin >> choice;
    while (choice < 1 || choice > 2)
    {
        cout << "Choice invalid. Please enter either 1 or 2.\n";
        cout << "\nPress 1 to Hit" << endl;
        cout << "Press 2 to Stay" << endl;
        cin >> choice;
    }

    while (choice == 1)
    {
        player.hit(deck.dealCard());
        player.getHand();
        if (player.checkBust()) break;
        cout << "\nPress 1 to Hit" << endl;
        cout << "Press 2 to Stay" << endl;
        cin >> choice;
    }

}

void playBlackJack()
{
   /*create a deck of cards and shuffle.  Cards are created within hte deck of cards class*/
    DeckOfCards deck;
    deck.shuffleDeck();
   

  /* create 2 players and deal each player 2 cards*/
    PlayerHand player1(deck.dealCard(), deck.dealCard());
    PlayerHand player2(deck.dealCard(), deck.dealCard());

    /*call method to check each players choices to stay or hold and also pass the deck of remaing cards in case they want to draw a card*/
    gameChoices(player1, deck);
    gameChoices(player2, deck);

    determineWinner(player1, player2);

}
// Find winner
void determineWinner(PlayerHand player1, PlayerHand player2)
{
    if (player1.getScore() > player2.getScore() && !player1.checkBust())
    {
        cout << "Player 1 Wins!\n";
    }
    else if (player1.getScore() < player2.getScore() && !player2.checkBust())
    {
        cout << "Sorry, Dealer wins.\n";
    }
    else if (!player1.checkBust() && player2.checkBust())
    {
        cout << "Player 1 Wins!\n";
    }
    else if (player1.checkBust() && !player2.checkBust())
    {
        cout << "Sorry, Dealer wins.\n";
    }
    else
    {
        cout << "It's a Push\n";
    }
}