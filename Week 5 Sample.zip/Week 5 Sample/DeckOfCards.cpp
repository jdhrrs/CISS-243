//deck of cards class implementaion

#pragma
#include "DeckOfCards.h"

// Constructor
DeckOfCards::DeckOfCards()
{
    int cardNum = 0;
    for (int suit = 0; suit < 4; suit++)
    {
        for (int face = 0; face < 13; face++)
        {
            Card temp(face + 1, suit + 1);
            fullDeckofCards[cardNum] = temp;
            cardNum++;

        }
    }
}


//Add the cards to the stack randomly
void DeckOfCards::shuffleDeck()
{
    int count;
    srand(time(0));
    int maxShuffles = 1800;
    
    for (int i = 0; i < SIZE; i++)
    {
        int pick = rand() % (52 - i);  /*picks a random number for hte card to be inserted into the stack from the remaing cards.*/
                
        Card temp;                        
        temp = fullDeckofCards[pick];
        fullDeckofCards[pick] = fullDeckofCards[i];
        fullDeckofCards[i] = temp;
    }

    for (count = 0; count < SIZE; count++)
    {
        shuffledDeck.push(fullDeckofCards[count]);
    }
}

//get a card for the player by popping a card off the top
Card DeckOfCards::dealCard()
{
    Card temp;
    temp = shuffledDeck.top();
    shuffledDeck.pop();
    return temp;
}



void DeckOfCards::showDeck()
{
    for (int count = 0; count < 52; count++)
    {
        cout << shuffledDeck.top() << endl;
        shuffledDeck.pop();
    }
}

