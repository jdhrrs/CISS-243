// Justin Harris 
// CISS 243 - Programming 3 
// 03/17/2023
// Class Hirearchie Program 

// Pseudo Code 
//********************************************************************************
// Define function printShips that takes an array of pointers to ship objects
// Inside printShips, iterate through array using a loop 
// for each iteration in the loop we will call print() method of the ship object
// Define function findTheOldestShip that takes an array of pointers to ship objects
// Inside the findTheOldestShip set pointer to the first ship objet in array as oldestShip 
// itearte through the array using a for loop 
// for each iteration of the loop compare year built of the ship object for oldestSHip
// Return oldest ship 
// Create an array of 6 pointers to the ship objects 
// Initalize elements of array with dynamically allocated Ship, CruiseShip, or CargoShip Object.
// call the printShips function passing in the array and the size 
// call the findTheOldestShip function passing in the array and size
// Print out the name of the oldest ship 
// Free dynamically allocated memory be deleting each element of the array using a for loop 
// end the porgram. 
// ***************************************************************************************
#include "Ship.h"
#include "CruiseShip.h"
#include "CargoShip.h"
#include <iostream>

using namespace std;

// A function that iterates through the array and calls the print method for each Ship object
void printShips(Ship** ships, int size) {
    for (int j = 0; j < size; j++) {
        ships[j]->print();
    }
}


// A function that determines which ship is older
Ship* findTheOldestShip(Ship** ships, int size) {
    Ship* oldestShip = ships[0];
    for (int j = 1; j < size; j++) {
        if (ships[j]->getYearBuilt() < oldestShip->getYearBuilt()) {
            oldestShip = ships[j];
        }
    }
    return oldestShip;
}

int main() {
    // Create an array of Ship pointers with 6 elements
    const int arraySize = 6;
    Ship* ships[arraySize];

    // Initialize the array elements with dynamically allocated Ship, CruiseShip, and CargoShip objects
    ships[0] = new Ship("Mayflower", 1620);
    ships[1] = new CruiseShip("Coral Princess", 2007, 1755);
    ships[2] = new CargoShip("Cosco Shipping Taurus", 2017, 500);
    ships[3] = new Ship("USS Arizona", 1916);
    ships[4] = new CruiseShip("Silver Spirit", 2019, 750);
    ships[5] = new CargoShip("MSC Diana", 2020, 19462);

    // Call the printShips function to print the ship details
    printShips(ships, arraySize);

    // Call the findTheOldestShip function to determine the oldest ship
    Ship* oldestShip = findTheOldestShip(ships, arraySize);
    cout << "The oldest ship is: " << oldestShip->getName() << endl;

    // Free the dynamically allocated memory
    for (int j = 0; j < arraySize; j++) {
        delete ships[j];
    }

    return 0;
}
