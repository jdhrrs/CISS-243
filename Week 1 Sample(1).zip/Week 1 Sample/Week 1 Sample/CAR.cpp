
#include "CAR.h"

    // Constructors
CAR:: CAR ():
make (" "), model (" "), color (" "), licenseNum (" ")
{ };

CAR:: CAR (string mK, string moD, string col, string lic)
{
    make = mK;
    model = moD;
    color = col;
    licenseNum = lic; 
}

CAR:: ~ CAR () {}; /// Deconsturctor

    // Getters (accessors)
string CAR:: getMake () const
{ return make; }

string CAR:: getModel() const
{ return model; }

string CAR:: getColor() const
{ return color; }

string CAR:: getLicenseNum() const
{ return this -> licenseNum; }

    // Setters  (mutators)
void CAR:: set_Make(string mAke)
{ make = mAke; }

void CAR:: set_Model(string mOdel)
{ model = mOdel; }

void CAR:: set_Color(string cOlor)
{ color = cOlor; }

void CAR:: set_LicenseNum(string lIcenseNum)
{ licenseNum = lIcenseNum; }

    // overloaded operator <<
ostream &operator << (ostream &strm, const CAR &obj)
{
    strm << "\n\tCar Information" << endl 
         << "Make: " << obj.getMake() << endl
         << "Model: " << obj.getModel() << endl
         << "Color: "<< obj.getColor() << endl
         << "License #: "<< obj.getLicenseNum() << endl;
    
    return strm;
}
