
#include "PARKING_METER.h"
    // Constructor / Deconstructor
PARCKING_METER:: PARCKING_METER ():
minsPurchased(0)
{ };

PARCKING_METER:: PARCKING_METER (int minPur)
{ this -> minsPurchased= minPur; }

PARCKING_METER:: ~ PARCKING_METER ()
{};

    // Getter (accessors)
int PARCKING_METER:: getMinsPur() const
{ return this ->minsPurchased; }

    // Setters (muators)
void PARCKING_METER:: set_MinsPur(int minPur)
{ this ->minsPurchased = minPur; }

    // Overloaded Operator
ostream &operator << (ostream &strm, const PARCKING_METER &obj)
{
    strm << "\tMeter Time: " << obj.getMinsPur() << endl;
    return strm;
}


