
#include "PARKED CAR.h"

PARKED_CAR:: PARKED_CAR ():
minsParked (0)
{ CAR parked; }; /// creating an instance of a CAR

PARKED_CAR:: PARKED_CAR (string make, string model, string color, string license, int minpark) /// setting PARKED_CAR & CAR object (info) Var
{
    minsParked = minpark;
    parked.set_Make(make);
    parked.set_Model(model);
    parked.set_Color(color);
    parked.set_LicenseNum(license);
    minsParked = minpark;
};




    // Getters (accessors)
int PARKED_CAR:: getMinsParked () const
{ return minsParked; };

    // Setters (mutators)
void PARKED_CAR:: set_MinsParked (int mins)
{ minsParked= mins; };

ostream &operator << (ostream &strm, const PARKED_CAR &obj)
{
    strm
    <<"\nCar Informaiton"
    <<"\n\tMake: " << obj.parked.getMake()
    <<"\n\tModel: " << obj.parked.getModel()
    <<"\n\tColor: " << obj.parked.getColor()
    <<"\n\tLicense: " << obj.parked.getLicenseNum()
    <<"\n\nParking Information"
    << "\n\tMinutes Parked: " << obj.getMinsParked() << endl;
    return strm;
};
