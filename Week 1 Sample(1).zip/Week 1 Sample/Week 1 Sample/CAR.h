//
//  CAR.hpp
//  Parking Meter
//
//  Created by Michael McDaniels on 3/8/21.
//

#ifndef CAR_hpp
#define CAR_hpp

#include <stdio.h>

#include <string>
#include <iostream>

using namespace std;
class CAR
{

    
private:
    string make, model, color, licenseNum;
    
public:
        // Constructors / Deconstructor
    CAR (); ///  Default constructor
    CAR (string mK, string moD, string col, string lic); 
    ~ CAR (); /// Deconstructor
        // Getters (mutators)
    string getMake () const;
    string getModel () const;
    string getColor () const;
    string getLicenseNum () const;
    
        // Setters (accessors)
    void set_Make (string mAke);
    void set_Model (string mOdel);
    void set_Color (string cOlor);
    void set_LicenseNum (string lIcenseNum);
    
        // Overload operator <<
    friend ostream &operator << (ostream &strm, const CAR &);
    
};

#endif /* CAR_hpp */
