

#include "POLICE_OFFICER.h"

    // Constructor & Deconstructor
POLICE_OFFICER:: POLICE_OFFICER (): ///  default
offName(" "), badgeNum(" ")  /// initialized list
{};

POLICE_OFFICER:: POLICE_OFFICER (string oN, string bNum)
{
    this->offName = oN;
    this->badgeNum = bNum;
}

POLICE_OFFICER:: ~POLICE_OFFICER () {};

    // Getter (accessors)
string POLICE_OFFICER:: getOffNm() const
{ return offName; }

string POLICE_OFFICER:: getBadgeNum() const
{ return badgeNum; }

    // Setter (muators)
void POLICE_OFFICER:: set_OffNm(string nM)
{ offName = nM; }

void POLICE_OFFICER:: set_OffBNum(string bN)
{ badgeNum = bN; };


bool POLICE_OFFICER:: patrol(const PARKED_CAR & pC, const PARCKING_METER &pM) /// will return turn true if a ticket need to be issued:::
{
  if (pC.getMinsParked()> pM.getMinsPur())
        {
            return true;
        }
    else
        {
           
            return false;
        }
};






    // overloaded << operator
ostream &operator << (ostream &strm, const POLICE_OFFICER &cop)
{
    strm
    <<"\nIssuing Officer: " << cop.getOffNm() << endl
    <<"Badge Number: " << cop.getBadgeNum() << endl;
    return strm;
}
