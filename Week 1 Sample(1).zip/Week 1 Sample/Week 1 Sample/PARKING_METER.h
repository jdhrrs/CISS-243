

#ifndef PARKING_METER_h
#define PARKING_METER_h

#include <stdio.h>
#include <iostream>

using namespace std; 

class PARCKING_METER
{
    int minsPurchased;
    
public:
    PARCKING_METER ();
    PARCKING_METER (int minPur);
    ~ PARCKING_METER ();
    
        // Getters (mutators)
    int getMinsPur () const;
        // Setters (accessors)
    void set_MinsPur (int minPur);
    
    friend ostream &operator << ( ostream &strm, const PARCKING_METER &);
};


#endif 
