
#ifndef PARKED_CAR_h
#define PARKED_CAR_h

#include <stdio.h>
#include "CAR.h"

class PARKED_CAR
{
private:
    int minsParked;
    
public:
    CAR parked; /// instance of CAR class
    
        // Constructors / Deconstructor
    PARKED_CAR ();
    PARKED_CAR (string make, string model, string color, string license, int minpark); 
    
    
    ~ PARKED_CAR () {};
    
        // Getters (mutators)
    int getMinsParked () const;
    
        // Setters (accessors)
    void set_MinsParked (int mins);
    
        // overloaded operator <<
    friend ostream & operator << (ostream &strm, const PARKED_CAR &); 
};

#endif 
