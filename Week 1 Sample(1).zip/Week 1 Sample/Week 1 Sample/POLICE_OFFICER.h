
#ifndef POLICE_OFFICER_h
#define POLICE_OFFICER_h
#include "PARKED CAR.h"
#include "PARKING_METER.h"
#include "PARKING_TICKET.h"

class POLICE_OFFICER
{
private:
    string offName, badgeNum;
    
public:
    
     
    
        // Constructor & Deconstructor
    POLICE_OFFICER();
    POLICE_OFFICER (string oN, string bNum);
    
    
    
    
    
    
    ~POLICE_OFFICER();
        // Getter (accessors)
    string getOffNm () const;
    string getBadgeNum () const;
    
        // Setter (muators)
    void set_OffNm (string nM);
    void set_OffBNum (string bN);
    
    
        // Functions
    //PARKING_TICKET patrol (const PARKED_CAR &, const PARCKING_METER &);
    
    bool patrol (const PARKED_CAR&, const PARCKING_METER &);
    
    PARKING_TICKET writeParkingT(const PARKED_CAR& pC, const PARCKING_METER& pM)
    {
        PARKING_TICKET prtTicket (pC, pM.getMinsPur());
        return prtTicket;
    };
    
        // overloaded << operator
    friend ostream &operator << (ostream &strm, const POLICE_OFFICER &);
};
#endif 
