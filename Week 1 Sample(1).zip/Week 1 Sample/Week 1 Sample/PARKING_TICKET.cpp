
#include "PARKING_TICKET.h"

    // Constructor & Deconstructor
PARKING_TICKET:: PARKING_TICKET () :
fine(0)
{ };

PARKING_TICKET:: PARKING_TICKET (const PARKED_CAR &obj, int pMt)
{
    car.parked.set_Make(obj.parked.getMake());
    car.parked.set_Model(obj.parked.getModel());
    car.parked.set_Color(obj.parked.getColor());
    car.parked.set_LicenseNum(obj.parked.getLicenseNum());
    car.set_MinsParked(obj.getMinsParked());
    
    calFine(pMt);
}

PARKING_TICKET:: ~ PARKING_TICKET () { };

    // Getter (accessors)
double PARKING_TICKET:: getFine () const
{ return fine;}

int PARKING_TICKET:: getOverTime() const
{ return over; }

    // Setter (muators)
void PARKING_TICKET:: set_fine(double fIne)
{ fine = fIne; }

void PARKING_TICKET:: set_Over(int oVer)
{ over= oVer;}

    // private functions
void PARKING_TICKET:: calFine (int pMt) /// set the fine:::
{
    over= car.getMinsParked() - pMt;
    if (over > 59)
        {
            fine = 25 + (over /60)*10; /// if it's over  59
        }
    else
        {
            fine =25; /// if it's under 59
        }
    
};

// overloaded << operator
ostream &operator << (ostream &strm, const PARKING_TICKET &obj)
{
    strm << fixed << setprecision(2)
    <<"\nCar Informaiton"
    <<"\n\tMake: " << obj.car.parked.getMake()
    <<"\n\tModel: " << obj.car.parked.getModel()
    <<"\n\tColor: " << obj.car.parked.getColor()
    <<"\n\tLicense: " << obj.car.parked.getLicenseNum()
    <<"\n\nParking Information"
    <<"\n\tMinutes Parked: " << obj.car.getMinsParked()
    <<"\n\tOver: " << obj.getOverTime()
    <<"\n\nFee"
    <<"\n\tTicket Price: $ " << obj.getFine() << endl;
    return strm;
}
