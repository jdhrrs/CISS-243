
/*********************
this program will calculate parking tickets given by an officer
methods / technques used
    classes
    operator overloading (<<)
    aggregation
    
**********************/

#include <iostream>
#include "PARKING_METER.h"
#include "PARKING_TICKET.h"
#include "POLICE_OFFICER.h"
using namespace std;



int main()
{
    PARKED_CAR car1 ("Honda", "Accord", "Black", "1X2375", 120);
    PARKED_CAR car2 (car1);  /// using the copy constructor
        // Resetting Parked_Car1
    car1.set_MinsParked(120);
    car1.parked.set_Make("BMW");
    car1.parked.set_Model("X1");
    car1.parked.set_Color("Green");
    car1.parked.set_LicenseNum("12WW572");
    PARCKING_METER meter1 (60);
    POLICE_OFFICER police ("James Bond", "007"); /// setting police information
    
    cout << endl;
    cout << "Car 1:" << car1;
    cout << "\nCar 2:" << car2; /// overloaded  parked car class
    cout << "\nParking Meter: "<< meter1;
    cout <<endl;
    cout <<  endl;

    
    car1.set_MinsParked(30); /// seting mins parked to under 60mins
    
    if (police.patrol(car1, meter1))
        {
        cout << police;
        cout << police.writeParkingT(car1, meter1);
        cout << meter1;
        }
    else
        {
        cout << "~~~~~~~~~~\tNo crimes were committed\t~~~~~~~~~~" << endl << endl;
        }


    
    
    
    cout << endl;
    car2.set_MinsParked(61); /// seting mins parked to under 60mins
    
    if (police.patrol(car2, meter1))
        {
        cout << police;
        cout << police.writeParkingT(car2, meter1);
        cout << meter1;
        }
    else
        {
        cout << "~~~~~~~~~~\tNo crimes were committed\t~~~~~~~~~~" << endl << endl;
        }
    
    cout <<endl;

    
    
    
    
    cout << endl;
    car1.set_MinsParked(120);
    if (police.patrol(car1, meter1))
        {
            cout << police;
            cout << police.writeParkingT(car1, meter1);
        cout << meter1;
        }
    else
        {
            cout << "~~~~~~~~~~\tNo crimes were committed\t~~~~~~~~~~" << endl << endl;
        }
    
    cout <<endl;

    
    
    
    cout << endl;
    car2.set_MinsParked(180);
    if (police.patrol(car2, meter1))
        {
        cout << police;
        cout << police.writeParkingT(car2, meter1);
        cout << meter1;
        }
    else
        {
        cout << "~~~~~~~~~~\tNo crimes were committed\t~~~~~~~~~~" << endl << endl;
        }
    
    cout <<endl;

    system("pause");
    return 0;
}


