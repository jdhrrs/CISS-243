
#ifndef PARCKING_TICKET_h
#define PARCKING_TICKET_h

#include <stdio.h>
#include <iomanip> 
#include <iostream>
#include "CAR.h"
#include "PARKED CAR.h"
#include "PARKING_METER.h"


using namespace std;
class PARKING_TICKET
{
private:
    double fine;
    double over;
    string make, model, color, license;
    void calFine (int);
    
public:
        // Constructor & Deconstructor
    PARKING_TICKET ();
    PARKING_TICKET (const PARKED_CAR &, int);
    ~ PARKING_TICKET ();
    PARKED_CAR car;
    
        // Getter (accessors)
    
    int getOverTime () const;
    double getFine () const;
    
        // Setter (muators)
    void set_fine (double fIne);
    void set_Over (int iPm);
  
    
        // overloaded << operator
    friend ostream &operator << (ostream &strm, const PARKING_TICKET &);
};

#endif 
