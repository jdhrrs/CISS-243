#ifndef LINKEDLIST_H
#define LINKEDLIST_H

template <typename T>
struct Node {
    T data;
    Node* next;
};

template <typename T>
class LinkedList {
public:
    LinkedList();
    ~LinkedList();
    void add(T data);
    void insert(int index, T data);
    void remove(int index);
    void update(int index, T data);
    T get(int index);
    int size();
private:
    Node<T>* head;
    int listSize;
};

#endif



