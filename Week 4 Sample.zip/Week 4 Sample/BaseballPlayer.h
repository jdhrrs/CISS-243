
#ifndef BASEBALLPLAYER_H
#define BASEBALLPLAYER_H
#include<string>
using namespace std;

class BaseballPlayer {
	
private:
	string name;
	int hits, homeRuns, walks, strikeOuts;
	
public:
	// Default constructor
	BaseballPlayer();
	// Constructor
	BaseballPlayer(string name, int hits, int homeRuns, int walks, int strikeOuts);
	void setName(string name);
	void setHits(int hits);
	void setHomeRuns(int homeRuns);
	void setWalks(int walks);
	void setStrikeOuts(int strikeOuts);

	string getName() const;
	int getHits() const;
	int getHomeRuns() const;
	int getWalks() const;
	int getStrikeOuts() const;
	int calculatePoints() const;

	// bool operator to overload 
	bool operator < (const BaseballPlayer& other) const;
	bool operator > (const BaseballPlayer& other) const;

	
	friend ostream& operator << (ostream& out, const BaseballPlayer& player);
};
#endif // !BASEBALLPLAYER_H