
#ifndef DERIVEDLINKEDLIST_H
#define DERIVEDLINKEDLIST_H
#include"LinkedList.h"

/*derived class for the linked list class that adds functionality to find the high and low value of any given data stored in the list*/
template <class T>
class derivedLinkedList :public LinkedList<T> {
public:
	T findHigh();
	T findLow();
};

// Template prototype
template<class T>
T derivedLinkedList<T>::findHigh() {
	ListNode<T>* nodePtr; // To move through the list
	nodePtr = this->head; // Position nodePtr at the head of the list
	T highVal;
	/*Initialize the first value of the node to be the high value*/
	if (nodePtr != nullptr) {
		highVal = nodePtr->value;
		nodePtr = nodePtr->next;
	}
	while (nodePtr) {
		if (nodePtr->value > highVal)
			highVal = nodePtr->value; /*If read value is greater than the current high value then update the value*/
		nodePtr = nodePtr->next; /*Then move onto the next value*/
	}
	return highVal; // Return the high value from the if/while function
}

// Template prototype 
template<class T>
T derivedLinkedList<T>::findLow() {
	ListNode<T>* nodePtr; // To move through the list
	nodePtr = this->head; // Position nodePtr at the head of the list
	T lowVal;
	/*Initialize the first value fo the node to be the low value*/
	if (nodePtr != nullptr) {
		lowVal = nodePtr->value;
		nodePtr = nodePtr->next;
	}
	while (nodePtr) {
		if (nodePtr->value < lowVal)
			lowVal = nodePtr->value; /*If read value is lower than the current low value then update the value*/
		nodePtr = nodePtr->next; /*Then move ont the next value*/
	}
	return lowVal; // Return the low value from the if/while function
}
#endif // !DERIVEDLINKEDLIST_H