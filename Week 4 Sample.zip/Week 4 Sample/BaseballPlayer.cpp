

#include"BaseballPlayer.h"
#include<iostream>

// Constructor with variables initialized
BaseballPlayer::BaseballPlayer() {
	name = "";
	hits = 0;
	homeRuns = 0;
	walks = 0;
	strikeOuts = 0;
}

/*Constructor extending the BaseballPlayer */
BaseballPlayer::BaseballPlayer(string name, int hits, int homeRuns, int walks, int strikeOuts) {
	this->name = name;
	this->hits = hits;
	this->homeRuns = homeRuns;
	this->walks = walks;
	this->strikeOuts = strikeOuts;
}

// Setters or Mutators of the data members
void BaseballPlayer::setName(string name) {
	this->name = name;
}
void BaseballPlayer::setHits(int hits) {
	this->hits = hits;
}
void BaseballPlayer::setHomeRuns(int homeRuns) {
	this->homeRuns = homeRuns;
}
void BaseballPlayer::setWalks(int walks) {
	this->walks = walks;
}
void BaseballPlayer::setStrikeOuts(int strikeOuts) {
	this->strikeOuts = strikeOuts;
}

// Getters or Assessors of the data
string BaseballPlayer::getName() const {
	return name;
}
int BaseballPlayer::getHits() const {
	return hits;
}
int BaseballPlayer::getHomeRuns() const {
	return homeRuns;
}
int BaseballPlayer::getWalks() const {
	return walks;
}
int BaseballPlayer::getStrikeOuts() const {
	return strikeOuts;
}

// Function to calculate the points. 
int BaseballPlayer::calculatePoints() const {
	int points = 0;
	if (hits > 0)
		points += hits;
	if (homeRuns > 0)
		points += 4 * homeRuns;
	if (walks > 0)
		points += walks;
	if (strikeOuts > 0)
		points -= strikeOuts;
	return points;
}


bool BaseballPlayer::operator<(const BaseballPlayer& other) const {
	int player1Points = calculatePoints();
	int player2Points = other.calculatePoints();
	if (player1Points < player2Points)
		return true;
	else
		return false;
}
bool BaseballPlayer::operator>(const BaseballPlayer& other) const {
	int player1Points = calculatePoints();
	int player2Points = other.calculatePoints();
	if (player1Points > player2Points)
		return true;
	else
		return false;
}

ostream& operator<<(ostream& output, const BaseballPlayer& Player) {
	output << "the player named: " << Player.name << "\n# of hits: " << Player.hits << "\n# of home runs: " << Player.homeRuns << "\n# of walks: " << Player.walks << "\n# of strike outs: " << Player.strikeOuts << endl << "\nTotal # of points caculated: " << Player.calculatePoints() << endl;
	cout << "**************************************************" << endl;
	return output;
	
}