//Sample program for exception handling for CISS 243

#include <iostream>
#include "ShapeTemplate.h"
#include "ShapeTemplate.cpp"
#include "NegativeValue.h"
using namespace std;

//main function
int main()
{
		int x = -5;
		double y = 99.99;


	//process the int value

	try {
		//Shape <int> intShape; //test int template
		Shape<int>intShape;
		intShape.setlength(x);

		cout << "the size is " << intShape.getLength() << endl;
	}
	catch (NegativeValue nv) {   //catches the error that is thrown back from the method.
		cout << "The error is " << nv.getMessage() << endl;
		
	};
	
	
	///process the double value


	try {
		Shape <double> doubleShape;   // create a double shape
		doubleShape.setlength(y);

		cout << "the size is " << doubleShape.getLength() << endl;
	}
	catch (NegativeValue nv) {   //catches the error that is thrown back from the method.
		cout << "The error is " << nv.getMessage() << endl;

	};
	
	system("pause");
	return 0;

}
