#include "ShapeTemplate.h"
#include "NegativeValue.h"
using namespace std;

template <class T>
Shape<T>::Shape() {};  //default constructor needs to be supplied if you have overridden const

template <class T>
Shape<T>::Shape(T size)	//overridden constructor
{
	length = size;
}

///Set the length
template <class T>
void Shape<T>::setlength(T l)
{
	try {
		if (l < 0) {   // if value less than 0 created an exception object, set the message and throw the object
			NegativeValue nv;
			nv.setMessage("*** INVALID VALUE ***");
			throw nv;
		}
		else {
			this->length = l;
		}
	}
	catch (NegativeValue nv) {  //catches the error object and throws the error back to the main method
		//cout << "The value can not be a negative number" << endl;
		throw nv;

	}
}

/// gets the length
template <class T>
	T Shape<T>::getLength()
	{
		return length;
	}


