#pragma once
#include <string>
using namespace std;

class NegativeValue {
public:
	NegativeValue();
	void setMessage(string);
	string getMessage();
private:
	string message;
	
};