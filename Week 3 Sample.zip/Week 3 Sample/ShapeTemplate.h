
#pragma once
#include"NegativeValue.h"
using namespace std;

template <class T>
class Shape
{
protected:
	T length;					
public:
	Shape();   //default constructor needs to be supplied if you have overridden const
	Shape(T size);	//overridden constructor
	void setlength(T);
	T getLength();
};







