#include"NegativeValue.h"

NegativeValue::NegativeValue() {}
void NegativeValue::setMessage(string m)
{
	message = m;
}
string NegativeValue::getMessage()
{
	return message;
}
;