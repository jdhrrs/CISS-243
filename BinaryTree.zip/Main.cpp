// Justin Harris 
// CISS 243 - Programming III 
// 04/18/2023
// Binary Tree Program 

// Pseudo Code ******************************************************
// This program creates a binary tree to store EmployeeInfo objects. 
// It then adds 10 employees to the tree using the insertNode() method. 
// The program then asks the user to enter an EmployeeID to search for 
// and then uses the searchNode() function to search for the employee.  
// If the employee is found, it dispays a message indicating so, otherside
// it will display a message saying that employee was not found. The program 
// then asks the user to enter an employee ID remove. and uses the remove()
// function to remove the employees from the tree. finally it displays the tree 
// in Order using the displayInOrder() method. 
// ********************************************************************************
//
//
//
//













#include <iostream>
#include "EmployeeInfo.h"
#include "BinaryTree.h"

using namespace std;

int main() {
    // Create a binary tree for EmployeeInfo objects
    BinaryTree<EmployeeInfo> tree;

    // Add some employees to the tree
    tree.insertNode(EmployeeInfo(1, "John Doe", "123 Main St", "555-1234", Date(2020, 1, 1), 50000.0));
    tree.insertNode(EmployeeInfo(2, "Jane Smith", "456 Elm St", "555-5678", Date(2020, 2, 1), 60000.0));
    tree.insertNode(EmployeeInfo(3, "Bob Johnson", "789 Oak St", "555-9012", Date(2020, 3, 1), 70000.0));
    tree.insertNode(EmployeeInfo(4, "Sue Davis", "234 Pine St", "555-3456", Date(2020, 4, 1), 80000.0));
    tree.insertNode(EmployeeInfo(5, "Bill Wilson", "567 Cedar St", "555-7890", Date(2020, 5, 1), 90000.0));
    tree.insertNode(EmployeeInfo(6, "Mary Brown", "890 Maple St", "555-1234", Date(2020, 6, 1), 100000.0));
    tree.insertNode(EmployeeInfo(7, "Tom Green", "111 Elm St", "555-5678", Date(2020, 7, 1), 110000.0));
    tree.insertNode(EmployeeInfo(8, "Amy Lee", "222 Oak St", "555-9012", Date(2020, 8, 1), 120000.0));
    tree.insertNode(EmployeeInfo(9, "Mike Adams", "333 Pine St", "555-3456", Date(2020, 9, 1), 130000.0));
    tree.insertNode(EmployeeInfo(10, "Karen White", "444 Cedar St", "555-7890", Date(2020, 10, 1), 140000.0));

    // Test searchNode() method
    int searchId;
    cout << "Enter employee ID to search for: ";
    cin >> searchId;
    if (tree.searchNode(EmployeeInfo(searchId, "", "", "", Date(), 0.0))) {
        cout << "Employee found!" << endl;
    }
    else {
        cout << "Employee not found!" << endl;
    }

    // Test remove() method
    int removeId;
    cout << "Enter employee ID to remove: ";
    cin >> removeId;
    tree.remove(EmployeeInfo(removeId, "", "", "", Date(), 0.0));

    // Display the tree in order
    cout << "Tree in order:" << endl;
    tree.displayInOrder();

    return 0;
    system("pause");
}

