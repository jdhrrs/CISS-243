#ifndef EMPLOYEEINFO_H
#define EMPLOYEEINFO_H

#include "Person.h"
#include "Date.h"
// Constructor that takes six parameters and initalizes the corresponding variable. 
class EmployeeInfo : public Person {
public:
    EmployeeInfo(int i = 0, const std::string& n = "", const std::string& a = "", const std::string& p = "", const Date& hd = Date(), double sal = 0.0);
    bool operator<(const EmployeeInfo& other) const;
    bool operator==(const EmployeeInfo& other) const;
    int getId() const; // Getters and Setters 
    void setId(int i);
    Date getDateHired() const;
    void setDateHired(const Date& hd);
    double getSalary() const;
    void setSalary(double sal);
private:
    int id; // Private variables 
    Date dateHired;
    double salary;
};

#endif
