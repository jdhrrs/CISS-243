#include "Date.h"
#include <iostream>

using namespace std;

Date::Date(int d, int m, int y) { // Constructor 
    setDay(d);
    setMonth(m);
    setYear(y);
}

int Date::getDay() const { // Getter
    return day;
}

void Date::setDay(int d) { // Setter 
    day = d;
}

int Date::getMonth() const { // Getter
    return month;
}

void Date::setMonth(int m) { //Setter
    month = m;
}

int Date::getYear() const { // Getter 
    return year;
}

void Date::setYear(int y) { //Setter
    year = y;
}

void Date::print() const { // This function prints the date in the format. defines a static array of strings 
    // containing the the names of the months, then uses this array and the month day year variables to output 
    // the date. The array is zero indezed meaning we need to subtract 1 from month values in indexing the array. 
    static const string months[] = {
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    };
    cout << months[month - 1] << " " << day << ", " << year << endl;
}
