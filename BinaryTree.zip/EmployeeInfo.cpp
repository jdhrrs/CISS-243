#include "EmployeeInfo.h"
// Class that takes 6 parameters. 
EmployeeInfo::EmployeeInfo(int i, const std::string& n, const std::string& a, const std::string& p, const Date& hd, double sal)
    : Person(n, a, p), id(i), dateHired(hd), salary(sal) {}

bool EmployeeInfo::operator<(const EmployeeInfo& other) const
{
    return false; // For comparison between employee objects
}

bool EmployeeInfo::operator==(const EmployeeInfo& other) const
{
    return false; // For comparison between employee objects 
}

int EmployeeInfo::getId() const { // Getters and Setters 
    return id;
}

void EmployeeInfo::setId(int i) {
    id = i;
}

Date EmployeeInfo::getDateHired() const {
    return dateHired;
}

void EmployeeInfo::setDateHired(const Date& hd) {
    dateHired = hd;
}

double EmployeeInfo::getSalary() const {
    return salary;
}

void EmployeeInfo::setSalary(double sal) {
    salary = sal;
}
