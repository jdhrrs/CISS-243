#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>

class Date { // Constructor 
public:
    Date(int d = 1, int m = 1, int y = 2000);
    int getDay() const; // Getter and setter methods for day, month, and year. 
    void setDay(int d);
    int getMonth() const;
    void setMonth(int m);
    int getYear() const;
    void setYear(int y);
    void print() const; // Method for printing the date in correct format. 
private:  // Private member variable for day, month and year. 
    int day;
    int month;
    int year;
};

#endif