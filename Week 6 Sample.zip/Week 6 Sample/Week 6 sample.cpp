//Week 6 Sample Program
/********************************************************************

Create three recursive functions that accomplish the following:

*********************************************************************/

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

/********************************************************************
Recursive Power Function this function will raise a number to a power.
*********************************************************************/
int recursivePower(int x, unsigned y)//unsigned can not be negative int.
{
    if (y == 0)
        return 1; //anything to the power of 0 is 1

    else
        return (x * recursivePower(x, y - 1));//if Y = 0, it must return 0, as anything * 0 is 0
}

/********************************************************************
String Reverser function that accepts a string object as its argument
and prints the string in reverse order.

*********************************************************************/
void recursiveString(string a, int b)
{
    if (b < a.length())
    {
        recursiveString(a, b + 1);
        cout << a[b];//print the string down to the 0 spot i
    }
}

/********************************************************************
Sum of Numbers this function accepts an integer argument and returns
the sum of all the numbers
*********************************************************************/
int recursiveSum(int n)
{
    if (n <= 0)
    {
        return 0;
    }
    else {
        return (n + recursiveSum(n - 1));
    }

}

/********************************************************************************
Main Method
**********************************************************************************/
int main()
{
    //call powers function
    unsigned e = 0;
    int myNumber = 0;
    cout << "Please Enter a Number :  \n";
    cin >> myNumber;
    cout << "Please Enter the Exponent: \n";
    cin >> e;
    cout << "You have choosen the number  " << myNumber << ", and the exponent " << e << ".\n";
    cout << "The Result is " << recursivePower(myNumber, e) << "\n";
    cout << "***************************************************\n";

    //call reverse string funciton
    string stringToReverse;
    cout << "Please Enter Your line : ";
    cin >> stringToReverse;
    cout << "Your Line " << stringToReverse <<
        " becomes ";
    recursiveString(stringToReverse, 0);
    cout << " when flipped";
    cout << endl;
    cout << "***************************************************\n";


    //sum of all numbers
    cout << "The sum of all numbers till a number you choose.\n";
    cout << "Please Enter a Number: \n";
    cin >> myNumber;
    cout << "The sum is  " << recursiveSum(myNumber) << ".\n";
    cout << "**************************************************\n";



    system("pause");
    return 0;
}
