#pragma once

#include <string>
#include <iostream>

// Header file
#include "Ship.h"

class CruiseShip : public Ship
{
private:

	// Member variable
	int max_passengers;

public:
	
	// Constructor
	CruiseShip(string, int, int);

	// Mutators
	void setMax_Passengers(int aMaxpassengers);

	// Accessors
	int getMax_Passengers();

	// Virtual Print
	virtual void print()
	{
		cout << "Ship Name:" << getShip_Name() << endl;
		cout << "Max Passengers:" << max_passengers << endl;
	}

};



