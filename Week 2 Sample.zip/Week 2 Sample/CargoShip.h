#pragma once

#include <string>
#include <iostream>

// Header
#include "Ship.h"
class CargoShip :    public Ship
{
private:

	// Member variable
	
	int cargo_capacity;

public:

	//constructor
	
	CargoShip(string, int, int);


	//Mutators
	void setCargo_Capacity(int aCargoCap);

	// Accessors
	int getCargo_Capacity();

	// Virtual print
	virtual void print()
	{
		cout << "Ship Name:" << getShip_Name() << endl;
		cout << "Cargo Capacity:" << cargo_capacity << " Tons" <<endl;
	}

};

