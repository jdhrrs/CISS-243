#include "CruiseShip.h"
#include "Ship.h"
// Header
#include <string>
#include <iostream>

using namespace std;


// Constructor
CruiseShip::CruiseShip (string aName, int aYear, int aMaxPassengers) : Ship(aName, aYear)
{
	max_passengers = aMaxPassengers;
}

// Mutators
void CruiseShip::setMax_Passengers(int aMaxPassengers)
{
	max_passengers = aMaxPassengers;
}

// Accessors
int CruiseShip::getMax_Passengers()
{
	return max_passengers;
}




