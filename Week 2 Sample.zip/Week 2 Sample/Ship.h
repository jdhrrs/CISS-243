#pragma once

// Header
#include <string>
#include <iostream>

using namespace std;

// Ship class
class Ship
{
private:

	// Member variables
	string ship_name;
	int year_built;

public:

// Constructor
	Ship(string aName, int aYear);

	// Mutators
	void setShip_Name(string aName);
	void setYear_Built(int aYear);

	// Accessors
	string getShip_Name();
	int getYear_Built();

	// Virtual Print
	virtual void print()
	{
		cout << "Ship Name:" << ship_name << endl;
		cout << "Year Built:" << year_built << endl;
	}

};

