#include <string>
#include <iostream>
#include "Ship.h"
#include "CargoShip.h"

// Constructor
CargoShip::CargoShip (string aName, int aYear, int aCargoCap) : Ship(aName, aYear)
{
	cargo_capacity = aCargoCap;
}

// Mutators
void CargoShip::setCargo_Capacity(int aCargoCap)
{
	cargo_capacity = aCargoCap;
}

// Accessors
int CargoShip::getCargo_Capacity()
{
	return cargo_capacity;
}


