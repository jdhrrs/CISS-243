#include "Ship.h"
// Header
#include <string>
#include <iostream>

using namespace std;

// Constructor
Ship::Ship(string aName, int aYear)
{
	ship_name = aName;
	year_built = aYear;
}

// Mutators
void Ship::setShip_Name(string aName)
{
	ship_name = aName;
}
void Ship::setYear_Built(int aYear)
{
	year_built = aYear;
}

// Acccesors
string Ship::getShip_Name()
{
	return ship_name;
}
int Ship::getYear_Built()
{
	return year_built;
}


