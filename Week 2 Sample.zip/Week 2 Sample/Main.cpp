// programmer name
//date written
//description of what the program does

#include "Ship.h"
#include "CruiseShip.h"
#include "CargoShip.h"
#include <string>
#include <iostream>
using namespace std;

// Oldest ship function
void oldest_ship(Ship *ship[])
{
	// Variables
	int old_ship = 9999;
	Ship* oldShip{};

	//For loop of oldest ship
	for (int i = 0; i < 6; i++)
	{
		// If statement
		if (ship[i]->getYear_Built() < old_ship)
		{
			// looks for the year
			old_ship = ship[i]->getYear_Built();
			oldShip = ship[i];
		}
	}

	// Display oldest ship
	cout <<"Oldest Ship:" << endl;
	oldShip->print();
}

// Print function into main 
void Dispaly(Ship *ship[])
{
	// For loop to print
	for (int i = 0; i < 6; i++)
	{
		ship[i]->print();
	}
}
// start main function
int main()
{
	// Defines the Ship class
	Ship ship_A("Trump", 1946);
	Ship ship_B("Biden", 1942);

	// Defines the CrusieShip class
	CruiseShip crusieship_A("Princess of the Seas", 2013, 3600);
	CruiseShip cruiseship_B("Valorant", 2016, 2980);

	//Defines the CargoShip class
	CargoShip cargoship_A("Panamax", 2006, 52500);
	CargoShip cargoship_B("Tina", 2007, 47980);

	// Pointer array for ship
	Ship *ship[6] = { &ship_A, &ship_B, &crusieship_A, &cruiseship_B, &cargoship_A, &cargoship_B };

	// Utilies the print function
	Dispaly(ship);

	// utilities the olest ship function
	oldest_ship(ship);

	return 0;

}


